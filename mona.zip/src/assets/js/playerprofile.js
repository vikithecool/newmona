/**
 * Created by vinesh.chauhan on 4/4/2017.
 */
var baseURL = windowLocation.origin + '/api/v1';
var playerID = $('#playerId').val();
var playerURL = baseURL + "/player/get-player-profile-info/" + playerID;
var playerMatchURL = baseURL + "/player/get-player-match/" + playerID;
var playerStatURL = baseURL + "/player/get-player-statistic/" + playerID;
var playerAwardsURL = baseURL + "/player/get-player-award/" + playerID;
var playerAwardsMatchesURL = baseURL + "/player/get-player-award-new/" + playerID + "/matches";
var playerAwardsTournamentURL = baseURL + "/player/get-player-award-new/" + playerID + "/tournament";
var playerTeamsURL = baseURL + "/player/get-player-team/" + playerID;
var playerPhotosURL = baseURL + "/player/get-player-match-media/" + playerID;
var playerConnectionsURL = baseURL + "/player/get-player-connections/" + playerID;
var playerFilterURL = baseURL + "/player/get-player-filter/" + playerID;
var playerBadgesURL = baseURL + "/player/get-player-gamification/" + playerID;
var awardsLoad = false;
var loadMoreMatches = '';
var loadMoreTeams = '';
var loadMorePhotos = '';
var loadMoreMatchesHeroesURL = '';
var loadMoreTournamentHeroesURL = '';
var bindFilter = false;
let tournamentFilter = [];
let teamFilter = [];
let applyClick = false;
let tournamentFilterV = null, teamFilterV = null, ballTypeFilterV = null, inningFilterV = null, crossFilterData = [];
let playerConnectionsData, log_user_id = "";
var matchAwardsIndex = 0;
var tournamentAwardsIndex = 0;

var asocID = $('#asocId').val();
var yearID = $('#yearId').val();

$(document).ready(function () {
  //Set player Id for follow...!!!
  $('.follow-player-web').attr('player-id', playerID);
  //Handle click event...!!!
  $('.select-filter-tournament').on('change', function () {
    //Get tournamentIds...!!!
    let teamsData = [];
    let tournamentIds = $('.select-filter-tournament').val();
    if (tournamentIds !== undefined && tournamentIds !== null) {
      tournamentIds.forEach(function (d) {
        crossFilterData.filter(function (data) {
          if (data.tournament_id == d) {
            teamsData.push(data);
          }
        })
      });
    }
    bindTeamFilter(teamsData);
  });
  // $('.select-filter-teams').on('change', function () {
  //   //Get tournamentIds...!!!
  //   let tournamentData = [];
  //   let teamIds = $('.select-filter-teams').val();
  //   if (teamIds !== undefined && teamIds !== null) {
  //     teamIds.forEach(function (d) {
  //       crossFilterData.filter(function (data) {
  //         if (data.team_id == d) {
  //           tournamentData.push(data);
  //         }
  //       })
  //     });
  //   }
  //   bindTournamentFilter(tournamentData);
  // });

  //Reset Filters...!!!
  $('#resetFilter').on('click', function () {
    $('.select-filter-tournament').val('').trigger('change');
    $('.select-filter-teams').val('').trigger('change');
    $('.select-filter-balltype').val('').trigger('change');
    $('.select-filter-innings').val('').trigger('change');
  });
  //Handle apply filter click event...!!!
  $('#applyFilter').on('click', function () {
    applyClick = true;
    filterProcess();
  });
  $('.pmd-floating-action-btn').on('click', function () {
    bindPlayerCustomFilter();
  })
  $('.filter-player-profile').on('click', function () {
    applyClick = false;
    tournamentFilterV = $('.select-filter-tournament').val();
    teamFilterV = $('.select-filter-teams').val();
    ballTypeFilterV = $('.select-filter-balltype').val();
    inningFilterV = $('.select-filter-innings').val();
  })
  //Handle Show Event
  $('.filter-dialog').on('show.bs.modal', function () {
    if (navigator.userAgent.toLowerCase().indexOf('mobile') > -1) {
      $('body').css('position', 'fixed');
    }
    document.querySelector('meta[name="viewport"]').content = 'width=device-width, minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0';
  });
  //Handle Model Hide event
  $('.filter-dialog').on('hidden.bs.modal', function () {
    if (navigator.userAgent.toLowerCase().indexOf('mobile') > -1) {
      $('body').css('position', '');
    }
    document.querySelector('meta[name="viewport"]').content = 'viewport" content="width=device-width, initial-scale=1';
    if (!applyClick) {
      if (tournamentFilterV !== null) {
        $('.select-filter-tournament').val(tournamentFilterV).trigger('change');
      }
      if (teamFilterV !== null) {
        $('.select-filter-teams').val(teamFilterV).trigger('change');
      }
      if (ballTypeFilterV !== null) {
        $('.select-filter-balltype').val(ballTypeFilterV).trigger('change');
      }
      if (inningFilterV !== null) {
        $('.select-filter-innings').val(inningFilterV).trigger('change');
      }
    }
  });
  let filterString = "";
  let filterCount = 0;

  function filterProcess() {
    //reset the URL...!!!
    playerMatchURL = baseURL + "/player/get-player-match/" + playerID;
    playerStatURL = baseURL + "/player/get-player-statistic/" + playerID;
    playerAwardsURL = baseURL + "/player/get-player-award/" + playerID;
    playerTeamsURL = baseURL + "/player/get-player-team/" + playerID;
    playerPhotosURL = baseURL + "/player/get-player-match-media/" + playerID;
    playerAwardsMatchesURL = baseURL + "/player/get-player-award-new/" + playerID + "/matches";
    playerAwardsTournamentURL = baseURL + "/player/get-player-award-new/" + playerID + "/tournament";

    let tournamentFilter = "";
    let teamFilter = "";
    let ballTypeFilter = "";
    let inningsFilter = "";
    let oversFilter = "";
    filterString = "";
    filterCount = 0;
    //For tournament filter...!!!
    if ($('.select-filter-tournament').val() !== null) {
      tournamentFilter = "tournamentId=" + $('.select-filter-tournament').val().toString();
      filterCount = filterCount + $('.select-filter-tournament').val().length;
    }
    if ($('.select-filter-teams').val() !== null) {
      teamFilter = "teamId=" + $('.select-filter-teams').val().toString();
      filterCount = filterCount + $('.select-filter-teams').val().length;
    }
    if ($('.select-filter-balltype').val() !== null) {
      ballTypeFilter = "ballType=" + $('.select-filter-balltype').val().toString();
      filterCount = filterCount + $('.select-filter-balltype').val().length;
    }
    if ($('.select-filter-innings').val() !== null) {
      inningsFilter = "matchInning=" + $('.select-filter-innings').val().toString();
      filterCount = filterCount + $('.select-filter-innings').val().length;
    }
    if ($('.select-filter-overs').val() !== null) {
      oversFilter = "matchOver=" + $('.select-filter-overs').val().toString();
      filterCount = filterCount + $('.select-filter-overs').val().length;
    }

    // prepare filter string ...!!!
    if (tournamentFilter !== "") {
      filterString = filterString + tournamentFilter;
    }
    if (teamFilter !== "") {
      if (tournamentFilter !== "") {
        filterString = filterString + "&" + teamFilter;
      }
      else {
        filterString = filterString + teamFilter;
      }
    }
    if (ballTypeFilter !== "") {
      if (tournamentFilter !== "" || teamFilter !== "" || oversFilter !== "") {
        filterString = filterString + "&" + ballTypeFilter;
      }
      else {
        filterString = filterString + ballTypeFilter;
      }
    }
    if (inningsFilter !== "") {
      if (tournamentFilter !== "" || teamFilter !== "" || ballTypeFilter !== "" || oversFilter !== "") {
        filterString = filterString + "&" + inningsFilter;
      }
      else {
        filterString = filterString + inningsFilter;
      }
    }
    if (oversFilter !== "") {
      if (tournamentFilter !== "" || teamFilter !== "" || ballTypeFilter !== "" || inningsFilter !== "") {
        filterString = filterString + "&" + oversFilter;
      }
      else {
        filterString = filterString + oversFilter;
      }
    }
    //Set badge for filter...!!!
    if (filterCount !== 0) {
      $('.badge-filter').css('display', 'block');
      $('.badge-filter').attr('data-badge', filterCount);
    }
    else {
      $('.badge-filter').css('display', 'none');
      $('.badge-filter').attr('data-badge', filterCount);
    }
    //Bind Matches Of Player with filter...!!!
    var p = false;
    if ($('#type').val() != "") {
      p = true;
    }
    playerMatchURL = playerMatchURL + "?" + filterString;
    playerStatURL = playerStatURL + "?" + filterString;
    playerAwardsURL = playerAwardsURL + "?" + filterString;
    playerTeamsURL = playerTeamsURL + "?" + filterString;
    playerPhotosURL = playerPhotosURL + "?" + filterString;
    playerAwardsMatchesURL = playerAwardsMatchesURL + "?" + filterString;
    playerAwardsTournamentURL = playerAwardsTournamentURL + "?" + filterString;

    if ($('.nav-tabs li.active a').attr('href') === "#MATCHES") {
      $('.matchesDiv').html('');
      bindPlayerMatch(p);
    }
    if ($('.nav-tabs li.active a').attr('href') === "#STATS") {
      bindStatistics();
    }
    if ($('.nav-tabs li.active a').attr('href') === "#AWARD" || $('.nav-tabs li.active a').attr('href') === "#playermatches" || $('.nav-tabs li.active a').attr('href') === "#playertournaments") {
      $('.matchesStat').html('');
      $('.tournamentsStat').html('');
      bindMatchAwards();
      bindTournamentAwards();
    }
    if ($('.nav-tabs li.active a').attr('href') === "#TEAM") {
      $('.teamsDiv').html('');
      bindTeams();
    }
    if ($('.nav-tabs li.active a').attr('href') === "#PHOTOS") {
      $('.my-gallery').html('');
      bindMatchMedia();
    }
  }

  $('#matchestab').on('click', function () {
    $('.matchesDiv').html('');
    bindPlayerMatch(true);
  });
  $('#badgesTab').on('click', function () {
    bindPlayerBadges();
  })
  $('#statTab').on('click', function () {
    bindStatistics();
  });
  $('#awardsTab').on('click', function () {
    $('.matchesStat').html('')
    $('.tournamentsStat').html('')
    bindMatchAwards();
    bindTournamentAwards();
  });
  $('#connectionsTab').on('click', function () {
    bindPlayerConnections();
  });
  $('#followingTab').on('click', function () {
    setTimeout(function () {
      $("#owl-carousel").trigger('refresh.owl.carousel');
    }, 200)
  })
  $('#followerTab').on('click', function () {
    setTimeout(function () {
      $("#owl-carousel").trigger('refresh.owl.carousel');
    }, 200)
  })
  $('#teamsTab').on('click', function () {
    if (loadMoreTeams != "" && loadMoreTeams.indexOf('pageno=2') == -1) {
      filterProcess();
    }
    $('.teamsDiv').html('');
    bindTeams();
  })
  $(".loadMoreMatches").on("click", function () {
    playerMatchURL = baseURL + loadMoreMatches;
    bindPlayerMatch(true);
  });
  $(".loadMoreTeams").on("click", function () {
    playerTeamsURL = baseURL + loadMoreTeams;
    bindTeams();
  });
  $('#photosTab').on('click', function () {
    if (loadMorePhotos != "" && loadMorePhotos.indexOf('pageno=2') == -1) {
      filterProcess();
    }
    $('.my-gallery').html('');
    bindMatchMedia();
  })
  $(".loadMorePhotos").on("click", function () {
    playerPhotosURL = baseURL + loadMorePhotos;
    bindMatchMedia();
  });
  $(".loadMoreMatchHeroes").on("click", function () {
    playerAwardsMatchesURL = baseURL + loadMoreMatchesHeroesURL;
    bindMatchAwards();
  });
  $(".loadMoreTournamentHeroes").on("click", function () {
    playerAwardsTournamentURL = baseURL + loadMoreTournamentHeroesURL;
    bindTournamentAwards();
  });

  //Set Meta Description For The Same...!!!
  $('meta[name="description"]').attr('content', $('#description').text())
  //Like award of match or tournament for player...!!!
  $('.loader').show();
  var headers;
  if ($('#type').val() != "" && $('#token').val() != "" && $('#udid').text() != "") {
    headers = {
      "api-key": Constants.Api.apiKey,
      "udid": $('#udid').text(),
      "device-type": getDeviceType(),
      "Authorization": $('#token').val()
    };
  }
  else {
    headers = {
      "api-key": Constants.Api.apiKey,
      "udid": getUDID(),
      "device-type": getDeviceType(),
    };
  }

  var request = $.ajax({
    url: playerURL,
    type: "GET",
    dataType: "json",
    headers: headers
  });
  request.done(function (data) {
    $('.loader').hide();
    if (data.status && data.data != undefined) {
      $('#playerView,.player-views-mobile-text').text(data.data.total_views + " Views");
      //Set Player name...!!!
      log_user_id = data.data.log_user_id;
      if (log_user_id == playerID) {
        $('.follow-player-web').remove()
      }
      $('.user-profile .pmd-card-title-text').text(data.data.name);
      $('.user-profile-mobile-content .pmd-card-title-text').text(data.data.name);
      //Set Player Profile Photo Image...!!!
      $('.player-photo').attr('src', prepareS3MediaURL(data.data.profile_photo, 'user_profile', s3LambdaConstant.PLAYER_LOGO.width, s3LambdaConstant.PLAYER_LOGO.height));
      data.data.is_player_pro === 1 ? $('.pro-tag').show() : $('.pro-tag').hide();
      $('.player-photo').attr('alt', data.data.name + " on CricHeroes");
      $('.player-photo').parent().attr('href', data.data.profile_photo);
      //Set Player Banner Image...!!!
      $('#player-banner.player-banner').css("background", "url(" + data.data.profile_photo + ") no-repeat center center");
      $('#player-banner.player-banner').css("background-size", "cover");
      $('.background-image').css("background", "url(" + data.data.profile_photo + ") no-repeat center center");
      $('.background-image').css("background-size", "cover");
      if (navigator.userAgent.toLowerCase().indexOf('mobile') != -1) {
        $('#player-banner').css('background', '');
      }
      if ($('#type').val() != "" && $('#token').val() != "" && data.data.is_follow == 1) {
        $('.follow-player').addClass('select');
        $('.follow-player').text('FOLLOWING');
      }
      initPhotoSwipeFromDOM('.profile_photo_gallary');
      //Bind Matches Of Player...!!!
      var p = false;
      if ($('#type').val() != "") {
        p = true;
      }


      bindPlayerProfile(data.data);
      if (asocID == '' && yearID == '') {
        bindPlayerMatch(p);
      }
      // var request = $.ajax({
      //   url: playerFilterURL,
      //   type: "GET",
      //   dataType: "json",
      //   headers: headers
      // });
      // request.done(function (data) {
      //   crossFilterData = data.data;
      //   //Fill filter value in select2 ...!!!
      //
      //   bindTournamentFilter(crossFilterData);
      //   if (asocID == '' && yearID == '') {
      //     bindPlayerMatch(p);
      //   }
      //
      //   //Set filter for team names...!!!
      //   bindTeamFilter(crossFilterData);
      //
      //   bindOversFilter(crossFilterData);
      //   $(".select-filter-balltype").select2({
      //     // tags: false,
      //     theme: "bootstrap",
      //   });
      //   $(".select-filter-innings").select2({
      //     // tags: false,
      //     theme: "bootstrap",
      //   });
      // });
      //bindPlayerCustomFilter()
    }
    else {
      window.location.href = "/not-found";
    }
  });
  request.fail(function (error) {
    $('.loader').hide();
    // alert(error.responseJSON.message);
  })

  function bindPlayerCustomFilter() {
    if (!bindFilter) {
      var request = $.ajax({
        url: playerFilterURL,
        type: "GET",
        dataType: "json",
        headers: headers
      });
      request.done(function (data) {
        bindFilter = true;
        crossFilterData = data.data;
        //Fill filter value in select2 ...!!!

        bindTournamentFilter(crossFilterData);
        // if (asocID == '' && yearID == '') {
        //   bindPlayerMatch(p);
        // }

        //Set filter for team names...!!!
        bindTeamFilter(crossFilterData);

        bindOversFilter(crossFilterData);
        $(".select-filter-balltype").select2({
          // tags: false,
          theme: "bootstrap",
        });
        $(".select-filter-innings").select2({
          // tags: false,
          theme: "bootstrap",
        });
      });
    }
  }

  function bindOversFilter(data) {
    let oversFilter;
    oversFilter = data.length === 0 ? crossFilterData : data;
    oversFilter = oversFilter.map(function (d) {
      return d.overs != "" ? {id: d.overs, text: d.overs} : null;
    });
    //remove null...!!!
    oversFilter = oversFilter.filter(Boolean);
    oversFilter = new Map(oversFilter.map(o => [o.id, o]));
    oversFilter = [...oversFilter.values()];
    oversFilter.sort(function (a, b) {
      var x = a.id.toLowerCase();
      var y = b.id.toLowerCase();
      return x > y ? -1 : x < y ? 1 : 0;
    })
    let selval = $(".select-filter-overs").val();
    $(".select-filter-overs").empty();
    $(".select-filter-overs").select2({
      data: oversFilter,
      // tags: false,
      theme: "bootstrap",
    })
  }

  function bindTeamFilter(data) {
    let teamFilter;
    teamFilter = data.length === 0 ? crossFilterData : data;
    teamFilter = teamFilter.map(function (d) {
      return d.team_name != "" ? {id: d.team_id, text: d.team_name} : null;
    });
    //remove null...!!!
    teamFilter = teamFilter.filter(Boolean);
    teamFilter = new Map(teamFilter.map(o => [o.id, o]));
    teamFilter = [...teamFilter.values()];

    let selval = $(".select-filter-teams").val();
    $(".select-filter-teams").empty();
    $(".select-filter-teams").select2({
      data: teamFilter,
      // tags: false,
      theme: "bootstrap",
    })
  }

  function bindTournamentFilter(data) {
    //Fill filter value in select2 ...!!!
    let tournamentFilter;
    tournamentFilter = data.length === 0 ? crossFilterData : data;
    tournamentFilter = tournamentFilter.map(function (d) {
      return d.tournament_name != "" ? {
        id: d.tournament_id,
        text: d.tournament_name,
        association_id: d.association_id,
        association_year_id: d.association_year_id
      } : null;
    });
    //remove null...!!!
    tournamentFilter = tournamentFilter.filter(Boolean);
    tournamentFilter = new Map(tournamentFilter.map(o => [o.id, o]));
    tournamentFilter = [...tournamentFilter.values()];
    let selval = $(".select-filter-tournament").val();
    $(".select-filter-tournament").empty();
    $(".select-filter-tournament").select2({
      data: tournamentFilter,
      // tags: false,
      theme: "bootstrap",
    });
    if (asocID > 0 && yearID > 0) {
      let filteredTournaments = tournamentFilter.filter(function (el) {
        return el.association_id == asocID && el.association_year_id == yearID
      });
      let filteredTournamentsIds = filteredTournaments.map(({id}) => id);
      if (filteredTournamentsIds != null && filteredTournamentsIds.length > 0) {
        $(".select-filter-tournament").val(filteredTournamentsIds).trigger('change');
        $('.pmd-textfield-floating-tournament-label label').css('transform', 'translateY(0)');
        $('.pmd-textfield-floating-tournament-label label').css('font-size', '14px');
        filterProcess();
      }
    }
  }

  function bindStatistics() {
    $('.loader').show();
    var request = $.ajax({
      url: playerStatURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      $('.stats .nav-tabs li').removeClass('active');
      $('.stats .tab-pane').removeClass('active');
      $('.stats .nav-tabs li').eq(0).addClass('active');
      $('.stats .tab-pane').eq(0).addClass('active');
      $('.battingStat').html('');
      $('.bowlingStat').html('');
      $('.fieldingStat').html('');
      if (data.status && data.data != undefined) {
        if (data.data.statistics.batting != undefined && data.data.statistics.batting.length > 0) {
          data.data.statistics.batting.forEach(function (batting) {
            $('.battingStat').append(generatingTemplate(playerProfileStat, batting));
          });
        }
        else {
          var value = {
            type: "No batting statistics found."
          }
          $('.battingStat').append(generatingTemplate(playerProfileStateBlankStat, value));
        }
        if (data.data.statistics.bowling != undefined && data.data.statistics.bowling.length > 0) {
          data.data.statistics.bowling.forEach(function (bowling) {
            $('.bowlingStat').append(generatingTemplate(playerProfileStat, bowling));
          })
        }
        else {
          var value = {
            type: "No bowling statistics found."
          }
          $('.bowlingStat').append(generatingTemplate(playerProfileStateBlankStat, value));
        }
        if (data.data.statistics.fielding != undefined && data.data.statistics.fielding.length > 0) {
          data.data.statistics.fielding.forEach(function (fielding) {
            $('.fieldingStat').append(generatingTemplate(playerProfileStat, fielding));
          })
        }
        else {
          var value = {
            type: "No fielding statistics found."
          }
          $('.fieldingStat').append(generatingTemplate(playerProfileStateBlankStat, value));
        }
      }
      $("#owl-carousel").trigger('refresh.owl.carousel');
    });
    request.fail(function (error) {
      $('.loader').hide();
    });

  }

  function bindPlayerMatch(p) {
    $('.loader').show();
    var request = $.ajax({
      url: playerMatchURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      if (data.status && data.data != undefined) {
        if (data.page.hasOwnProperty('next')) {
          loadMoreMatches = data.page.next;
          $(".loadMoreMatches").show();
        } else {
          loadMoreMatches = "";
          playerMatchURL = baseURL + "/player/get-player-match/" + playerID + "?" + filterString;
          $(".loadMoreMatches").hide();
        }
        if (data.data.length > 0) {
          bindMatches(data.data, true, false);
        }
      }
      else {
        loadMoreMatches = "";
        $(".loadMoreMatches").hide();
        var dataM = {};
        dataM.type = "Player did not played any matches yet.";
        $(".matchesDiv").append(generatingTemplate(noMatchesExist, dataM));
        setTimeout(function () {
          $("#owl-carousel").trigger('refresh.owl.carousel');
        }, 300)
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
      alert(error.responseJSON.error.message);
    })
  }

  function bindAwards() {
    $('.loader').show();
    let request = $.ajax({
      url: playerAwardsURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      if (data.status && data.data != undefined) {
        $('.awards .nav-tabs li').removeClass('active');
        $('.awards .tab-pane').removeClass('active');
        $('.awards .nav-tabs li').eq(0).addClass('active');
        $('.awards .tab-pane').eq(0).addClass('active');
        $('.tournamentsStat').html('');
        $('.matchesStat').html('');
        // Bind tournaments awards...!!!
        var dataTemplate = {};
        if (data.data.tournaments != undefined && data.data.tournaments.length > 0) {
          $.each(data.data.tournaments, function (index, value) {
            value.i = index;
            value.from_date = d3.timeFormat('%d-%b,%Y')(new Date(value.from_date));
            value.to_date = d3.timeFormat('%d-%b,%Y')(new Date(value.to_date));
            if (value.name == "PLAYER OF TOURNAMENT") {
              value.award_class = "player-of-match";
              value.award_icon = "player_of_the_tournament.png";
              value.type = 4;
            }
            else if (value.name == "BEST BATSMAN") {
              value.award_class = "best-batsman";
              value.award_icon = "batsman_tournament.png";
              value.type = 5;
            }
            else {
              value.award_class = "best-bowler";
              value.award_icon = "bowler_tournament.png";
              value.type = 6;
            }
            if (value.tournament_name == "") {
              value.tournament_name = "Individual match";
            }

            $('.tournamentsStat').append(generatingTemplate(playerProfileAwardsTournaments, value));
            if ($('#type').val() != "" && $('#token').val() != "" && value.is_loggedin_endorse == 1) {
              $('#awardTeamDetail' + value.i).parent().parent().find('.like').toggleClass('toggle_award');
              $('#awardTeamDetail' + value.i).parent().parent().find('.like img').attr('src', '/assets/images/like_filled.png');
            }
            //Bind batting or bowling template...!!!
            if (value.batting != undefined && value.batting.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbatting, value));
              // Bind Batting statistics template with data...!!!
              value.batting.forEach(function (batting) {
                $('#awardBattingStat' + value.i).append(generatingTemplate(playerprofileTournamentAwardbattingStat, batting));
              });
            }
            if (value.bowling != undefined && value.bowling.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbowling, value));
              // Bind Bowling statistics template with data...!!!
              value.bowling.forEach(function (bowling) {
                $('#awardBowlingStat' + value.i).append(generatingTemplate(playerprofileTournamentAwardbowlingStat, bowling));
              });
            }
          });
        }
        else {
          dataTemplate.type = "Looks like the player hasn't won any tournament awards yet.";
          $('.tournamentsStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
          $("#owl-carousel").trigger('refresh.owl.carousel');
        }
        //Bind Match Awards
        if (data.data.matches != undefined && data.data.matches.length > 0) {
          i = 0;
          if (data.data.tournaments != undefined) {
            i = data.data.tournaments.length + 1;
          }
          $.each(data.data.matches, function (index, value) {
            value.i = i + index;
            value.match_date_time = d3.timeFormat('%d-%b,%Y')(new Date(value.match_date_time));
            if (value.name == "PLAYER OF MATCH") {
              value.award_class = "player-of-match";
              value.award_icon = "player_of_the_match_icon.png";
              value.type = 1;
            }
            else if (value.name == "BEST BATSMAN") {
              value.award_class = "best-batsman";
              value.award_icon = "batsman_icon.png";
              value.type = 2;
            }
            else {
              value.award_class = "best-bowler";
              value.award_icon = "bowler_icon.png";
              value.type = 3;
            }
            if (value.tournament_name == "") {
              value.tournament_name = "Individual match";
            }

            $('.matchesStat').append(generatingTemplate(playerProfileAwards, value));
            if ($('#type').val() != "" && $('#token').val() != "" && value.is_loggedin_endorse == 1) {
              $('#awardTeamDetail' + value.i).parent().parent().find('.like').toggleClass('toggle_award');
              $('#awardTeamDetail' + value.i).parent().parent().find('.like img').attr('src', '/assets/images/like_filled.png');
            }
            //Bind batting or bowling template...!!!
            if (value.batting != undefined && value.batting.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbatting, value));
              // Bind Batting statistics template with data...!!!
              value.batting.forEach(function (batting) {
                batting.display_star = "";
                if (batting.is_out == 0) {
                  batting.display_star = "*";
                }
                $('#awardBattingStat' + value.i).append(generatingTemplate(playerprofileAwardbattingStat, batting));
              });
            }
            if (value.bowling != undefined && value.bowling.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbowling, value));
              // Bind Bowling statistics template with data...!!!
              value.bowling.forEach(function (bowling) {
                $('#awardBowlingStat' + value.i).append(generatingTemplate(playerprofileAwardbowlingStat, bowling));
              });
            }
          });
        }
        else {
          dataTemplate.type = "Looks like the player hasn't won any awards yet.";
          $('.matchesStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
          $("#owl-carousel").trigger('refresh.owl.carousel');
        }
        awardsLoad = true;
        $('.like-count').filter(function () {
          if ($(this).html() == "0") {
            $(this).html('')
          }
        })
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
    });
  }

  function bindTeams() {
    $('.loader').show();
    var request = $.ajax({
      url: playerTeamsURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      if (data.status) {
        if (data.page.hasOwnProperty('next')) {
          loadMoreTeams = data.page.next;
          $(".loadMoreTeams").show();
        } else {
          loadMoreTeams = "";
          playerTeamsURL = baseURL + "/player/get-player-team/" + playerID + "?" + filterString;
          $(".loadMoreTeams").hide();
        }
        if (data.data != undefined) {

          data.data.forEach(function (team) {
            team.created_date = d3.timeFormat('%d-%b,%Y')(new Date(team.created_date));
            team.team_url = window.location.origin + "/team-profile/" + team.team_id + "/" + team.team_name.replace(/ /g, '-');
            team.logo = prepareS3MediaURL(team.logo, 'team_logo', s3LambdaConstant.TEAM_ICON.width, s3LambdaConstant.TEAM_ICON.height);
            $('.teamsDiv').append(generatingTemplate(playerprofileAwardTeamStat, team))
          })
        }
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
      else {
        $('.teamsDiv').html();
        $('.teamsDiv').append(generatingTemplate(teamPlayerBlankState, ''));
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
    });

  }

  function bindMatchMedia() {
    $('.loader').show();
    var request = $.ajax({
      url: playerPhotosURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      if (data.status) {
        if (data.page.hasOwnProperty('next')) {
          loadMorePhotos = data.page.next;
          $(".loadMorePhotos").show();
        } else {
          loadMorePhotos = "";
          playerPhotosURL = baseURL + "/player/get-player-match-media/" + playerID + "?" + filterString;
          $(".loadMorePhotos").hide();
        }
        if (data.data != undefined && data.data.length > 0) {
          data.data.forEach(function (media) {
            if (media.is_photo == 1) {
              media.media_thumb = prepareS3MediaURL(media.media, 'match_media', s3LambdaConstant.MATCH_MEDIA.width, s3LambdaConstant.MATCH_MEDIA.height);
              $('.my-gallery').append(generatingTemplate(mediaMatchTemplate, media));
            }
            else {
              media.media = prepareS3MediaURL(media.media, 'match_media', s3LambdaConstant.MATCH_MEDIA.width, s3LambdaConstant.MATCH_MEDIA.height);
              $('.my-gallery').append(generatingTemplate(mediaVideoMatchTemplate, media));
            }
            // getMeta(media.media, function (width, height) {
            //   $('#' + media.media_id).attr('data-size', width + "x" + height);
            // });
          });
        }
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
      else {
        $(".loadMorePhotos").hide();
        $('.my-gallery').html('');
        $('.my-gallery').append(generatingTemplate(tournamentMediaBlankStateTemplate, ''));
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
    });
  }

  function bindPlayerProfile(playerprofile) {
    $('.profileDiv').append(generatingTemplate(playerProfileView, playerprofile))
  }

  function bindPlayerConnections() {
    $('.loader').show();
    var request = $.ajax({
      url: playerConnectionsURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      data = data.data;
      $('.connections .nav-tabs li').removeClass('active');
      $('.connections .tab-pane').removeClass('active');
      $('.connections .nav-tabs li').eq(0).addClass('active');
      $('.connections .tab-pane').eq(0).addClass('active');
      $('.followingStat').html('');
      $('.followerStat').html('');
      let i = 1;
      if (data.following !== undefined && data.following.length > 0) {
        data.following.forEach(function (d) {
          d.index = i;
          let playerUrl = windowLocation.origin + "/player-profile/" + d.player_id + "/" + d.name.replace(/ /g, '-');
          d.player_url = playerUrl;
          d.profile_photo = prepareS3MediaURL(d.profile_photo, 'user_profile', s3LambdaConstant.PLAYER_ICON.width, s3LambdaConstant.PLAYER_ICON.height);
          if (d.is_player_pro === 1) {
            d.pro_image = "<img class='pro-tag pro-tag-connection' src = '/assets/images/pro_badge_without_shadow.png'>";
          } else {
            d.pro_image = "";
          }
          $('.followingStat').append(generatingTemplate(playerConnections, d));
          if (d.is_follow === 1) {
            $('.follow-index-' + i).addClass('select');
            $('.follow-index-' + i).text('Following');
          }
          i++;
        });
        $('#followingTab').text('Following (' + data.following.length + ")");
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
      else {
        $('.followingStat').append(generatingTemplate(playerconnectionsBlankState, {type: 'Not following any cricketer as of now.'}))
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
      if (data.follower !== undefined && data.follower.length > 0) {
        data.follower.forEach(function (d) {
          d.index = i;
          let playerUrl = windowLocation.origin + "/player-profile/" + d.player_id + "/" + d.name.replace(/ /g, '-');
          d.player_url = playerUrl;
          d.profile_photo = prepareS3MediaURL(d.profile_photo, 'user_profile', s3LambdaConstant.PLAYER_ICON.width, s3LambdaConstant.PLAYER_ICON.height);
          if (d.is_player_pro === 1) {
            d.pro_image = "<img class='pro-tag' src = '/assets/images/pro_badge_without_shadow.png'>";
          } else {
            d.pro_image = "";
          }
          $('.followerStat').append(generatingTemplate(playerConnections, d));
          if (d.is_follow === 1) {
            $('.follow-index-' + i).addClass('select');
            $('.follow-index-' + i).text('Following');
          }
          i++;
        });
        $('#followerTab').text('Followers (' + data.follower.length + ")");
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
      else {
        $('.followerStat').append(generatingTemplate(playerconnectionsBlankState, {type: 'No followers as of now.'}))
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
      $('.player' + log_user_id).remove();
      if (navigator.userAgent.toLowerCase().indexOf('mobile') != -1 && $('#type').val() != "" && $('#token').val() != "" && $('#udid').text() != "") {
        $('.follow-player-connection').removeClass('hide')
        bindFollowEvent('.follow-player-connection');
      }

      //Unbind player connection click...!!!
      if ($('#type').val() != "") {
        $('.team-profile-player a').removeAttr('href');
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
    });

  }

  function bindPlayerBadges() {
    $('#badgesDiv').html('');
    $('.loader').show();
    var request = $.ajax({
      url: playerBadgesURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      if (data.status === true) {
        if (data.data.length > 0) {
          data.data.forEach(function (d) {
            d.icon = prepareS3MediaURL(d.icon, 'gamification_icon', s3LambdaConstant.PLAYER_BADGES.width, s3LambdaConstant.PLAYER_BADGES.height);
            $('#badgesDiv').append(generatingTemplate(playerBadges, d));
          });
        }
        else {
          $('#badgesDiv').append(generatingTemplate(badgesBlankState, ''));
          $("#owl-carousel").trigger('refresh.owl.carousel');
        }
        $('.gamification-badge img').load(function () {
          $("#owl-carousel").trigger('refresh.owl.carousel');
        })
        // setTimeout(function () {
        //   $("#owl-carousel").trigger('refresh.owl.carousel');
        // },200);
      }
      else {
        $('#badgesDiv').append(generatingTemplate(badgesBlankState, ''));
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
    });
  }

  function bindMatchAwards() {
    $('.loader').show();
    var dataTemplate = {};
    var request = $.ajax({
      url: playerAwardsMatchesURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      if (data.page !== undefined && data.page.hasOwnProperty('next')) {
        loadMoreMatchesHeroesURL = data.page.next;
        $("#loadMoreMatchHeroes").show();
      } else {
        $("#loadMoreMatchHeroes").hide();
      }
      if (data.status && data.data != undefined) {
        $('.awards .nav-tabs li').removeClass('active');
        $('.awards .tab-pane').removeClass('active');
        $('.awards .nav-tabs li').eq(0).addClass('active');
        $('.awards .tab-pane').eq(0).addClass('active');

        //Bind Match Awards
        if (data.data != undefined && data.data.length > 0) {
          $.each(data.data, function (index, value) {
            value.i = matchAwardsIndex++;
            value.match_date_time = d3.timeFormat('%d-%b,%Y')(new Date(value.match_date_time));

            $('.matchesStat').append(generatingTemplate(playerProfileAwards, value));
            if ($('#type').val() != "" && $('#token').val() != "" && value.is_loggedin_endorse == 1) {
              $('#awardTeamDetail' + value.i).parent().parent().find('.like').toggleClass('toggle_award');
              $('#awardTeamDetail' + value.i).parent().parent().find('.like img').attr('src', '/assets/images/like_filled.png');
            }
            //Bind batting or bowling template...!!!
            if (value.batting != undefined && value.batting.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbatting, value));
              // Bind Batting statistics template with data...!!!
              value.batting.forEach(function (batting) {
                batting.display_star = "";
                if (batting.is_out == 0) {
                  batting.display_star = "*";
                }
                $('#awardBattingStat' + value.i).append(generatingTemplate(playerprofileAwardbattingStat, batting));
              });
            }
            if (value.bowling != undefined && value.bowling.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbowling, value));
              // Bind Bowling statistics template with data...!!!
              value.bowling.forEach(function (bowling) {
                $('#awardBowlingStat' + value.i).append(generatingTemplate(playerprofileAwardbowlingStat, bowling));
              });
            }
          });
        }
        else {
          if (loadMoreMatchesHeroesURL == undefined) {
            dataTemplate.type = "Looks like the player hasn't won any awards yet.";
            $('.matchesStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
            $("#owl-carousel").trigger('refresh.owl.carousel');
          }
        }
        $('.like-count').filter(function () {
          if ($(this).html() == "0") {
            $(this).html('')
          }
        })
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
      else {
        dataTemplate.type = "Looks like the player hasn't won any awards yet.";
        $('.matchesStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
      dataTemplate.type = "Looks like the player hasn't won any awards yet.";
      $('.matchesStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
      $("#owl-carousel").trigger('refresh.owl.carousel');
    });
  }

  function bindTournamentAwards() {
    var dataTemplate = {};
    $('.loader').show();
    var request = $.ajax({
      url: playerAwardsTournamentURL,
      type: "GET",
      dataType: "json",
      headers: headers
    });
    request.done(function (data) {
      $('.loader').hide();
      if (data.page !== undefined && data.page.hasOwnProperty('next')) {
        loadMoreTournamentHeroesURLHeroesURL = data.page.next;
        $("#loadMoreTournamentHeroes").show();
      } else {
        $("#loadMoreTournamentHeroes").hide();
      }
      if (data.status && data.data != undefined) {
        $('.awards .nav-tabs li').removeClass('active');
        $('.awards .tab-pane').removeClass('active');
        $('.awards .nav-tabs li').eq(0).addClass('active');
        $('.awards .tab-pane').eq(0).addClass('active');

        //Bind Tournament Awards
        if (data.data != undefined && data.data.length > 0) {
          $.each(data.data, function (index, value) {
            value.i = 't' + tournamentAwardsIndex++;
            value.from_date = d3.timeFormat('%d-%b,%Y')(new Date(value.from_date));
            value.to_date = d3.timeFormat('%d-%b,%Y')(new Date(value.to_date));

            $('.tournamentsStat').append(generatingTemplate(playerProfileAwardsTournaments, value));
            if ($('#type').val() != "" && $('#token').val() != "" && value.is_loggedin_endorse == 1) {
              $('#awardTeamDetail' + value.i).parent().parent().find('.like').toggleClass('toggle_award');
              $('#awardTeamDetail' + value.i).parent().parent().find('.like img').attr('src', '/assets/images/like_filled.png');
            }
            //Bind batting or bowling template...!!!
            if (value.batting != undefined && value.batting.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbatting, value));
              // Bind Batting statistics template with data...!!!
              value.batting.forEach(function (batting) {
                $('#awardBattingStat' + value.i).append(generatingTemplate(playerprofileTournamentAwardbattingStat, batting));
              });
            }
            if (value.bowling != undefined && value.bowling.length > 0) {
              $('#awardTeamDetail' + value.i).append(generatingTemplate(playerprofileAwardbowling, value));
              // Bind Bowling statistics template with data...!!!
              value.bowling.forEach(function (bowling) {
                $('#awardBowlingStat' + value.i).append(generatingTemplate(playerprofileTournamentAwardbowlingStat, bowling));
              });
            }
          });
        }
        else {
          if (loadMoreTournamentHeroesURLHeroesURL == undefined) {
            dataTemplate.type = "Looks like the player hasn't won any tournament awards yet.";
            $('.tournamentsStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
            $("#owl-carousel").trigger('refresh.owl.carousel');
          }
        }
        $('.like-count').filter(function () {
          if ($(this).html() == "0") {
            $(this).html('')
          }
        })
        $("#owl-carousel").trigger('refresh.owl.carousel');
      } else {
        dataTemplate.type = "Looks like the player hasn't won any tournament awards yet.";
        $('.tournamentsStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
        $("#owl-carousel").trigger('refresh.owl.carousel');
      }
    });
    request.fail(function (error) {
      $('.loader').hide();
      dataTemplate.type = "Looks like the player hasn't won any awards yet.";
      $('.matchesStat').append(generatingTemplate(playerProfileAwardsBlankStat, dataTemplate));
      $("#owl-carousel").trigger('refresh.owl.carousel');
    });
  }
});
$('#matchAwardsTab').on('click', function () {
  setTimeout(function () {
    $("#owl-carousel").trigger('refresh.owl.carousel');
  }, 100)
});
$('#matchTournamentTab').on('click', function () {
  setTimeout(function () {
    $("#owl-carousel").trigger('refresh.owl.carousel');
  }, 100)
});
// $('#playerBattingTab').on('click', function () {
//   setTimeout(function () {
//     $("#owl-carousel").trigger('refresh.owl.carousel');
//   }, 100)
// });
// $('#playerBowlingTab').on('click', function () {
//   setTimeout(function () {
//     $("#owl-carousel").trigger('refresh.owl.carousel');
//   }, 100)
// });
// $('#playerFieldingTab').on('click', function () {
//   setTimeout(function () {
//     $("#owl-carousel").trigger('refresh.owl.carousel');
//   }, 100)
// });

import { Component, OnInit } from '@angular/core';
import { MatchesService } from '../../service/matches.service';
import { HttpClient, HttpEvent, HttpRequest, HttpInterceptor, HttpHandler, HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-matches',
  templateUrl: './matches.component.html',
  styleUrls: ['./matches.component.css']
})
export class MatchesComponent implements OnInit {

  matches : any = [];
  constructor(public matchApi: MatchesService,private http: HttpClient) { }

  ngOnInit() {
      this.getmatch();
  }

  getmatch() {
    this.matchApi.getMatch().subscribe((result:any)=>{
      this.matches = result.data;
      console.log(this.matches)
   });
  }


}

import { Component, OnInit, ChangeDetectionStrategy  } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TabDirective } from 'ngx-bootstrap/tabs';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {

  value: string;
  onSelect(data: TabDirective): void {
    this.value = data.heading;
  }

  viewprofile: string[] = ['Matches','Stats','Awards','Badges','Teams','Photos','Connections','Profile'];
  selectedprofile = this.viewprofile[0];

  constructor(private router: Router) { }

  ngOnInit() {
  }


yourFn($event){
  if($event.index == 0){
    this.router.navigateByUrl("/stats");
  }else if($event.index == 1){
    this.router.navigateByUrl("");
  }else if($event.index == 2){
    this.router.navigateByUrl("");
  }else if($event.index == 3){
    this.router.navigateByUrl("");
  }

}
}

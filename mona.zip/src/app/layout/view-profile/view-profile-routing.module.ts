import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ViewProfileComponent } from './view-profile.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
const routes: Routes = [
  {
      path: '', component: ViewProfileComponent
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes),CommonModule, TabsModule.forRoot() ],
    exports: [RouterModule]
})
export class ViewProfileRoutingModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatchesComponent } from './matches.component';
import { MatchesRoutingModule } from './matches-routing.module';
import { ViewProfileComponent } from '../view-profile/view-profile.component';

@NgModule({
  declarations: [MatchesComponent,ViewProfileComponent],
  imports: [
    CommonModule,MatchesRoutingModule
  ]
})
export class MatchesModule { }

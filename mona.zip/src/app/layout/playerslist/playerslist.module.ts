import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlayerslistComponent } from './playerslist.component';
import { PlayerslistRoutingModule } from './playerslist-routing.module';
@NgModule({
  declarations: [PlayerslistComponent],
  imports: [
    CommonModule,PlayerslistRoutingModule
  ]
})
export class PlayerslistModule { }

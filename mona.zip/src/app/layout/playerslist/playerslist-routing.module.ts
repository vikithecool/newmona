import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PlayerslistComponent } from './playerslist.component';
const routes: Routes = [
  {
      path: '', component: PlayerslistComponent
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes),CommonModule ],
  exports: [RouterModule]
})
export class PlayerslistRoutingModule { }

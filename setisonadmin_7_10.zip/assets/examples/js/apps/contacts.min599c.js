/*!
 * Remark (http://getbootstrapadmin.com/remark)
 * Copyright 2017 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */

!function(global,factory){if("function"==typeof define&&define.amd)define("/apps/contacts",["jquery"],factory);else if("undefined"!=typeof exports)factory(require("jquery"));else{var mod={exports:{}};factory(global.jQuery),global.appsContacts=mod.exports}}(this,function(_jquery){"use strict";(0,babelHelpers.interopRequireDefault(_jquery).default)(document).ready(function(){AppContacts.run()})});